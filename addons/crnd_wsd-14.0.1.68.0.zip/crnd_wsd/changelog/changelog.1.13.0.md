- Update text editor (trumbowyg) to 2.18.0 version
- Remove 'superscript' and 'subscript' buttons from text editor's toolbar.
  These buttons seems to be unused.
