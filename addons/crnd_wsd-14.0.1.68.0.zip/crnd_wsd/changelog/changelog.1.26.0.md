Changed views, to show author as creator.
Before, on request page, only creator of request was shown.
After this update, in case when request was created on behalf of someone,
both, author and cretor, will be displayed on request page.
