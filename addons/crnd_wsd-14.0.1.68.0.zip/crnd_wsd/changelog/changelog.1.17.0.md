- Added implementation of readmore feature for request page.
  If request takes more then 500px height,
  then it will be limited with this height and link 'Read more' will be shown.
- Trumbowyg: removed tool-button *Insert Image* that is confusing for users.
- Added extra tooltips for request type, category and kind.
