# pylint: disable=unused-import
# For backward compatability
from odoo.addons.generic_mixin import render_jinja_string  # noqa
