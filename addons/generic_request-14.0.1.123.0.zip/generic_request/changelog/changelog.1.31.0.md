Added graph view for requests
