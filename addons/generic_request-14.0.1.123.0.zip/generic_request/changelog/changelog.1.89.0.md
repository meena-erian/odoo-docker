Now requests created via xml-RPC or json RPC will get *API* channel automatically
(if not provided in creation parameters)
